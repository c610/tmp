#!/usr/bin/env python
# modus.py - v0.7

# small script I called modus.py from 'modus operandi'.
# maybe you will find it useful.
# for some reason, try to keep it private for now.
# thanks.

#
# last update(s): please see CHANGELOG file.
#   have fun
# o/


# IMPORTS
from optparse import OptionParser
import sys
sys.path.append('Mods')
import os # os.listdir()
import re
from datetime import datetime, date, time
today = datetime.now()

# OPERANDS
import checking  # defined all 'basic' tests
import genix     # defined all 'basic' tests for genix
import horde     # based on Horde 5.2.2x
import wordpress # based on Wordprss 4.x
import dlink     # based on dir300
import piwigo    # based on piwigo 2.9.2

# import xyz-related-tests...ex:horde

# FUNCTIONS
# def:checkingFile -- check each file for defined.<test>
def checkingFile(path2file,target): # TODO threadzZzzzZZzz...

  # checking.<function_name> --  modules for v0.7:
  # checking.basic_xss_declar(path2file, target)
  # checking.basic_xss_funcMethod(path2file)
  # checking.basic_traversal(path2file)
  # checking.basic_unserialize(path2file)
  # genix.check_xss(path2file)
  # genix.check_sqli(path2file)
  # horde.check_xss_setget(path2file)
  # horde.check_xss_setdef(path2file)
  # wordpress.check_xss_methods(path2file)
  # wordpress.check_sqli_declar(path2file, target)
  # wordpress.check_sqli_methods(path2file)
  # wordpress.check_fileinc(path2file)
  # wordpress.check_rce(path2file)
  dlink.check_xss(path2file)
  # piwigo.check_xss(path2file)
  # piwigo.check_sqli_pwg_realesc(path2file)


# print ' ------------------------------------- ' # DEBUG

## eof:checkingFile
#


# def:banner()
def banner():
  print ''
  print '              [--]  modus v0.7  [--]  '
  print ''


## eof:banner

# def:main -- main started
def main():
  usage = "usage: %prog [-d <source directory to check>]"
  parser = OptionParser(usage)
  parser.add_option("-d", "--dirsrc", dest="target",
                    help="read src from TARGET directory")
  #  parser.add_option("-v", "--verbose",
  #                    action="store_true", dest="verbose")

  (options, args) = parser.parse_args()
  if len(args) > 1: # TODO
    parser.error("incorrect number of arguments")
  if options.target: # target directory with src to test
    target = options.target
    print '[start   ] %s' % ( today )
    print '[checking] target directory: %s' % (target)

    # read target directory to locate PHP files:
    for root, subdirs, files in os.walk(target):
      for file in os.listdir(root):
        fp = os.path.join(root, file)
        if os.path.isdir(fp): # TODO: verify .php/.php3 and similar sources.
                              # TODO: skip .zip files, some not-readable
                              # TODO: characters for python-grep-parsing...
          pass # pass if not-file(as-is)

        elif fp.endswith('.js',3):
          #print 'not checking: %s', fp
          pass
        else:
          # if new file found, run tests against it
          checkingFile(fp,target)

    #   for(file/root) finished.
    # for(target) finished.
    #
  # print '[info] finished our test(s).' # DEBUG
## eof:checkingFile


## eof:main
#

##
#### starts here ####
## MAIN ##
if __name__ == "__main__":
    banner()
    main()

## eof:Main()
#


# more: code610.blogspot.com
#----
# o/
#


