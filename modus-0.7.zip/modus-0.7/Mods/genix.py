#!/usr/bin/env python
# genix.py - this module was designed to spot the 'most basic'
#   bugs during the source code review of Genix CMS. 
#   based on version 1.1.5 (described also at the blog).
#   for now we have:
#
# redefined basic modules for v0.7:
#   -- check_xss -- check for functions with GET/POST, etc...
#   -- check_sqli -- to check some basic SQLi bugs found in Genix 
#

import os, re
from datetime import datetime, date, time
today = datetime.now()

#### GLOBALS ####
bugcount_xss_genix = 0
bugcount_sqli_genix = 0

####  MODULES ####
# def:check_sqli -- check for basic sqli bugs in Genix CMS
def check_sqli(path2file):

  fp = open(path2file, 'r')
  lines = fp.readlines()

  patterns = [
    "Db::result\(\"SELECT(.*?)\{\$(.*?)\}"
  ]
  global bugcount_sqli_genix
  pattN = 0
  for pattern in patterns:
    pattN = pattN + 1
    nline = 0
    for line in lines:
      nline = nline + 1

      findme = re.compile(pattern)
      foundme = re.search(findme, line)
       
      if foundme:
        bugcount_sqli_genix = bugcount_sqli_genix + 1
        param = foundme.group(2)
        print '---------------------------------------------------------------------------'
        print ' [bug:SQLi] | file %s (param: %s) | line %d ' % ( path2file, param, nline )
        print '---------------------------------------------------------------------------'
        print ' file: %s in line %d' % ( path2file, nline)
        print ''
        print '  short info: possible SQLi; wrong declaration'
        print ''
        print '  param: %s' % ( param )
        print '  code line:'
        print ''
        print line
        #print '---------------------------------------------------------------------------'
        print '\n\n'

        # TOTAL:
        print '[ Total found : %d ]' % ( bugcount_sqli_genix )



# eof:check_sqli()
#


# def:check_xss -- check for methods with functions
def check_xss(path2file):

  fp = open(path2file, 'r')
  lines = fp.readlines()
  global bugcount_xss_genix

  patterns = [
    # patterns below was used to find multiple bugs in the past.
    # of course there could be more. feel free to add it or
    # ping me to do it. any idea is welcome.

    # few examples:
    # ./Control/Backend/mods.control.php:21:$mod = Typo::cleanX($_GET['mod'])
    #      in GeniXCMS 1.1.5(? - latest anyway)
    #
    "\$(.*?) = Typo::cleanX\(\$_GET\['(.*?)'"

  ]
  nline = 0
  pattN = 0

  for pattern in patterns:
    pattN = pattN + 1

    for line in lines:
      nline = nline + 1
      findme = re.compile(pattern)
      foundme = re.search(findme, line)

      if foundme:
        bugcount_xss_genix = bugcount_xss_genix + 1
        param = foundme.group(2)
 
        print '---------------------------------------------------------------------------'
        print ' [bug:XSS] | file %s (param: %s) | line %d ' % ( path2file, param, nline ) 
        print '---------------------------------------------------------------------------'
        print ' file: %s in line %d' % ( path2file, nline)
        print ''
        print '  short desc: '
        print '    it looks like we got a basic XSS bug for Genix CMS. details below.'
        print ''
        print '  param: %s' % ( param )
        print '  code line:'
        print ''
        print line
        #print '---------------------------------------------------------------------------'
        print '\n\n'

        # TOTAL:
        print '[ Total found : %d ]' % ( bugcount_xss_genix ) 



#### 
# EOF v0.7
## 

# ---
# o/


