#!/usr/bin/env python
# dlink.py - this module was designed to spot the 'most basic'
#   XSS bugs during the source code review of Dlink router.
#   Based on version dir300. For now we have:
#
# redefined basic modules for v0.7:
#   -- check_xss -- 

import os, re
from datetime import datetime, date, time
today = datetime.now()

#### GLOBALS ####


####  MODULES ####
## def:dlink_xss -- quick test to grab some XSS ( based on dir300 )
def check_xss(path2file):
  fp = open(path2file, 'r')
  lines = fp.readlines()

  patterns = [
    "input (.*?)echo \$_GET\[\"(.*?)\"",
    "(.*?)echo \$_POST\[\"(.*?)\""
  ]

  pattN = 0
  for pattern in patterns:
    pattN = pattN + 1
    nline = 0
    for line in lines:
      nline = nline + 1

      findme = re.compile(pattern)
      foundme = re.search(findme, line)

      if foundme:
        param = foundme.group(2)
        print '---------------------------------------------------------------------------'
        print ' [bug:XSS:Dlink]   |  test:dlink.check_xss  (%s)  |  %s      ' % ( param, today )
        print '---------------------------------------------------------------------------'
        print ' file: %s in line %d' % ( path2file, nline)
        print ''
        print '  short desc: '
        print '    it looks like we got a basic SQLi bug. details below.'
        print ''
        print '  param: %s' % ( param )
        print '  code line:'
        print ''
        print line
        #print '---------------------------------------------------------------------------'
        print '\n\n'


# eof:check_xss
#



#### 
# EOF v0.7
## 

# ---
# o/


