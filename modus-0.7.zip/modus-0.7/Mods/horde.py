#!/usr/bin/env python
# horde.py - this module was designed to spot the 'most basic'
#   bugs during the source code review of Horde 5.2.x. 
#   based on version 5.2.21-22 (described also at the blog).
#   for now we have:
#
# redefined basic modules for v0.7:
#   -- check_xss_setget -- check for functions with GET/POST, etc...
#   -- check_xss_setdef -- check for functinos declared as setDefault
#

import os, re
from datetime import datetime, date, time
today = datetime.now()

#### GLOBALS ####
bugcount_xss_horde_setget = 0
bugcount_xss_horde_setdef = 0


####  MODULES ####
# def:xss_setdef -- based on: CVE-2017-1690[6-8]
def check_xss_setdef(path2file):

  fp = open(path2file, 'r')
  lines = fp.readlines()

  global bugcount_xss_horde_setdef

  nline = 0
  for line in lines:
    nline = nline + 1

    patterns = [
      "-\>setDefault\(\$vars->get\('(.*?)'"
    ]

    pattN = 0  # not 0; count pattern used to find the bug
    for pattern in patterns:
      pattN = pattN + 1
      find = re.compile(pattern)
      found = re.search(find, line)

      if found:
        bugcount_xss_horde_setdef = bugcount_xss_horde_setdef + 1
        param = found.group(1)
        print '---------------------------------------------------------------------------'
        print ' [bug:XSS:Horde] | file %s (param: %s) | line %d ' % ( path2file, param, nline )
        print '---------------------------------------------------------------------------'
        print ' file: %s in line %d' % ( path2file, nline)
        print ''
        print '  short info: possible XSS (setDefault) for Horde'
        print ''
        print '  param: %s' % ( param )
        print '  code line:'
        print ''
        print line
        #print '---------------------------------------------------------------------------'
        print '\n\n'

        # TOTAL:
        print '[ Total found : %d ]' % ( bugcount_xss_horde_setdef )

## eof:horde_xss_setdef
#






# def:horde_xss_setget -- XSS when set/get is not sanitized
def check_xss_setget(path2file):

  fp = open(path2file, 'r')
  lines = fp.readlines()

  global bugcount_xss_horde_setget
  nline = 0
  for line in lines:
    nline = nline + 1

    patterns = [
      # $vars->set('name', $resource->get('name'));
      "\$vars->set\('(.*?)',(.*?)->get\('(.*?)'"
    ]

    pattN = 0  # not 0; count pattern used to find the bug
    for pattern in patterns:
      pattN = pattN + 1
      find = re.compile(pattern)
      found = re.search(find, line)

      if found:
        bugcount_xss_horde_setget = bugcount_xss_horde_setget + 1
        param = found.group(3)
        print '---------------------------------------------------------------------------'
        print ' [bug:XSS:Horde] | file %s (param: %s) | line %d ' % ( path2file, param, nline )
        print '---------------------------------------------------------------------------'
        print ' file: %s in line %d' % ( path2file, nline)
        print ''
        print '  short info: possible XSS (set/get) for Horde'
        print ''
        print '  param: %s' % ( param )
        print '  code line:'
        print ''
        print line
        #print '---------------------------------------------------------------------------'
        print '\n\n'

        # TOTAL:
        print '[ Total found : %d ]' % ( bugcount_xss_horde_setget )

# eof:check_xss_setget
#

#### 
# EOF v0.7
## 

# ---
# o/


