#!/usr/bin/env python
# checking.py - this module was designed to spot the 'most basic'
#   bugs during the source code review. for now we have:
#

# redefined basic modules for v0.7:
#   -- basic_xss_funcMethod -- check for functions with GET/POST...
#   -- 
#

import os, re
from datetime import datetime, date, time
today = datetime.now()

#### GLOBALS ####
bugcount_xss_declar = 0


####  MODULES ####
## def:basic_unserialize
def basic_unserialize(path2file):

  fp = open(path2file, 'r')
  lines = fp.readlines()

  methods = ['GET','POST','REQUEST','COOKIE','SERVER','FILE']
  functions = [
    'unserialize','unserialize '
  ]

  nline = 0

  for line in lines:
    nline = nline + 1
    for function in functions:
      for method in methods:
        pattern = function + "(.*?)\\$_" + method + "\['(.*?)'\]"

        findme = re.compile(pattern)
        foundme = re.search(findme, line)

        param = ''
        if foundme:
          if not any(value in line for value in ("htmlspecial", "sprint", "implode")):

            param = foundme.group(2)

            print '---------------------------------------------------------------------------'
            print ' [bug:UNSERIALIZE]   |    test:basic_unserialize (%s)  |    %s           ' % ( param, today )
            print '---------------------------------------------------------------------------'
            print ' file: %s in line %d' % ( path2file, nline)
            print ''
            print '  short desc: '
            print '    it looks like we got an unserialize bug...'
            print '    some details below.'
            print ''
            print '  method: %s' % ( method )
            print '  function: %s' % ( function )
            print '  param: %s' % ( param )
            print '  code line:'
            print ''
            print line

## eof: basic_unserialize
# 




## def:basic_traversal(path2file)
def basic_traversal(path2file):
  fp = open(path2file, 'r')
  lines = fp.readlines()

  methods = ['GET','POST','REQUEST','FILES','COOKIE','SERVER']
  functions = [
    'readfile','readfile ',
    'fopen','fopen ',
    'is_readable','is_readable ',
    'glob','glob '
  ]

  nline = 0

  for line in lines:
    nline = nline + 1
    for function in functions:
      for method in methods:
        pattern = function + "(.*?)\\$_" + method + "\['(.*?)'\]"

        findme = re.compile(pattern)
        foundme = re.search(findme, line)

        param = ''
        if foundme:
          if not any(value in line for value in ("htmlspecial", "sprint", "implode")):

            param = foundme.group(2)
            print '---------------------------------------------------------------------------'
            print ' [bug:TRAVERSAL]   |    test:basic_traversal (%s)  |    %s           ' % ( param, today )
            print '---------------------------------------------------------------------------'
            print ' file: %s in line %d' % ( path2file, nline)
            print ''
            print '  short desc: '
            print '    it looks like we got a directory traversal bug...'
            print '    some details below.'
            print ''
            print '  method: %s' % ( method )
            print '  function: %s' % ( function )
            print '  param: %s' % ( param )
            print '  code line:'
            print ''
            print line
            print '\n\n'

## eof:basic_traversal
#









# checking lines similar to:
#   echo $_GET['paramName']
#   if line != sanitized -> bug
# 
def basic_xss_funcMethod(path2file):
  fp = open(path2file, 'r')
  lines = fp.readlines() 

  methods = [ 'GET','POST','REQUEST','SESSION','FILE','COOKIE' ]
  functions = [ 'echo ', 'return ', 'print ' ]

  nline = 0
  global bugcount_xss_declar
  for line in lines:
    nline = nline + 1
    for func in functions:
      for method in methods:
        pattern = func + "(.*?)\$_" + method + "\[(.*?)\]"
        find = re.compile(pattern)
        found = re.search(find, line)

        if found:
          bugcount_xss_declar = bugcount_xss_declar + 1
          param = found.group(2)
 
          print '---------------------------------------------------------------------------'
          print ' [bug:XSS] | file %s (param: %s) | line %d ' % ( path2file, param, nline ) 
          print '---------------------------------------------------------------------------'
          print ' file: %s in line %d' % ( path2file, nline)
          print ''
          print '  short desc: '
          print '    it looks like we got a basic XSS bug. details below.'
          print ''
          print '  param: %s' % ( param )
          print '  code line:'
          print ''
          print line
          #print '---------------------------------------------------------------------------'
          print '\n\n'

          # TOTAL:
          print '[ Total found : %d ]' % ( bugcount_xss_declar ) 

#### 
# EOF v0.7
## 

