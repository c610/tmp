#!/usr/bin/env python
# piwigo.py - this module was designed to spot the 'most basic'
#   bugs during the source code review of Piwigo 2.9.2.
#   For now we have:
#
# redefined basic modules for v0.7:
#   -- check_xss -- testing for basic XSS  
#   -- check_sqli_pwg_realesc -- checking for wrong sanitization 
#      when pwg_db_real_escape_string is used in query
#   -- ... 

import os, re
from datetime import datetime, date, time
today = datetime.now()

#### GLOBALS ####


####  MODULES ####
## def:check_sqli
def check_sqli_pwg_realesc(path2file):
  fp = open(path2file, 'r')
  lines = fp.readlines()

  methods = ['GET','POST','REQUEST']

  for method in methods:
    patterns = [
      # example:
      # ./admin/user_list_backend.php:86:
      #    ".pwg_db_real_escape_string( $_REQUEST['sSortDir_'.$i] ) .", ";
      "pwg_db_real_escape_string(.*?)\$_" + method + "\['(.*?)'",
      "WHERE(.*?)" + method + "\['(.*?)'"
    ]

    for pattern in patterns:
      nline = 0
      for line in lines:
        nline = nline + 1

        findme = re.compile(pattern)
        foundme = re.search(findme, line)

        if foundme:
          if not any(value in line for value in ("htmlspecial", "sprint", "implode")):
            param = foundme.group(2)
            param = foundme.group(2)
            print '---------------------------------------------------------------------------'
            print ' [bug:SQLI:Piwigo]   |  test:check_sqli_pwg_realesc (%s)  |  %s      ' % ( param, today )
            print '---------------------------------------------------------------------------'
            print ' file: %s in line %d' % ( path2file, nline)
            print ''
            print '  short desc: '
            print '    it looks like we got a basic SQLi bug for Piwigo. details below.'
            print ''
            print '  param: %s' % ( param )
            print '  code line:'
            print ''
            print line
            #print '---------------------------------------------------------------------------'
            print '\n\n'


## eof:check_sqli_pwg_realesc
# 





# def:piwigo_xss - find XSS bugs in Piwigo code (based on 2.9.2)
def check_xss(path2file):

  fp = open(path2file, 'r')
  lines = fp.readlines()

  patterns = [
    "span class=(.*?){/if}>{\$(.*?)}"
  ]

  pattN = 0
  for pattern in patterns:
    pattN = pattN + 1
    nline = 0
    for line in lines:
      nline = nline + 1

      findme = re.compile(pattern)
      foundme = re.search(findme, line)

      if foundme:
        param = foundme.group(2)
        print '---------------------------------------------------------------------------'
        print ' [bug:XSS:Piwigo]   |  test:piwigo.check_xss  (%s)  |  %s      ' % ( param, today )
        print '---------------------------------------------------------------------------'
        print ' file: %s in line %d' % ( path2file, nline)
        print ''
        print '  short desc: '
        print '    it looks like we got a basic XSS for Piwigo. details below.'
        print ''
        print '  param: %s' % ( param )
        print '  code line:'
        print ''
        print line
        #print '---------------------------------------------------------------------------'
        print '\n\n'


## eof:check_xss
# 


#### 
# EOF v0.7
## 

# ---
# o/


