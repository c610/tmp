#!/usr/bin/env python
# wordpress.py - this module was designed to spot the 'most basic'
#   bugs during the source code review of Wordpress 4.x. 
# 
#   for now we have:
#
# redefined basic modules for v0.7:
#   -- check_xss_methods
#   -- check_sqli_declar
#   -- check_fileinc
# 
import os, re
from datetime import datetime, date, time
today = datetime.now()

#### GLOBALS ####
bugcount_xss_methods = 0
bugcount_sqli_declar = 0

####  MODULES ####

## 
## def:wordpress_rce -- to get some RCE bugs if possibe (methods)
def check_rce(path2file):

  fp = open(path2file, 'r')
  lines = fp.readlines()

  methods = ['GET','POST','REQUEST','COOKIE','SERVER','FILES']
  functions = [
    'call_user_func', 'call_user_func ',
    'function_exists', 'function_exists '
  ]

  nline = 0

  for line in lines:
    nline = nline + 1
    for function in functions:
      for method in methods:
        pattern = function + "(.*?)\\$_" + method + "\['(.*?)'\]"

        findme = re.compile(pattern)
        foundme = re.search(findme, line)

        param = ''
        if foundme:
          if not any(value in line for value in ("htmlspecial", "sprint", "implode")):

            param = foundme.group(2)

            print '---------------------------------------------------------------------------'
            print ' [bug:RCE]   |    test:wordpress_rce (%s)  |         %s           ' % ( param, today )
            print '---------------------------------------------------------------------------'
            print ' file: %s in line %d' % ( path2file, nline)
            print ''
            print '  short desc: '
            print '    it looks like we got a basic "Wordpress-related" RCE bug...'
            print '    some details below.'
            print ''
            print '  method: %s' % ( method )
            print '  function: %s' % ( function )
            print '  param: %s' % ( param )
            print '  code line:'
            print ''
            print line
            print '\n\n'

## eof: check_rce
# 




## def:check_fileinc
def check_fileinc(path2file):
  # example:
  #   include 'admin/' . $_GET['action'] . '.php';

  fp = open(path2file, 'r')
  lines = fp.readlines()

  methods = ['GET','POST','REQUEST','COOKIE','SERVER','FILES']
  functions = [
    'include', 'include ',
    'include_once', 'include_once ',
    'require', 'require ',
    'require_once ', 'require_once '
  ]

  nline = 0

  for line in lines:
    nline = nline + 1
    for function in functions:
      for method in methods:
        pattern = function + "(.*?)\\$_" + method + "\['(.*?)'\]"

        findme = re.compile(pattern)
        foundme = re.search(findme, line)

        param = ''
        if foundme:
          if not any(value in line for value in ("htmlspecial", "sprint", "implode")):

            param = foundme.group(2)

            print '---------------------------------------------------------------------------'
            print ' [bug:INCLUDE]   |    test:wordpress_fileinc (%s)  |         %s           ' % ( param, today )
            print '---------------------------------------------------------------------------'
            print ' file: %s in line %d' % ( path2file, nline)
            print ''
            print '  short desc: '
            print '    it looks like we got a basic "Wordpress-related" include-bug...'
            print '    some details below.'
            print ''
            print '  method: %s' % ( method )
            print '  function: %s' % ( function )
            print '  param: %s' % ( param )
            print '  code line:'
            print ''
            print line
            print '\n\n'


## eof:check_fileinc
#


# def:check_sqli_methods(path2file)
def check_sqli_methods(path2file):

  fp = open(path2file, 'r')
  lines = fp.readlines()

  nline = 0
  for line in lines:
    nline = nline + 1
    methods = [ 'GET','POST','SERVER','COOKIE','FILE','SESSION' ]

    for method in methods:
    
      # pattern based on:
      #$timeline = $wpdb->get_results('SELECT * FROM ' . $wpdb->prefix . 'ctimelines WHERE id='.$_GET['id']);
      pattern = "\$wpdb->get_results\('SELECT(.*?)WHERE (.*?)=(.*?)\$_" + method + "\[(.*?)\]\);"
      find = re.compile(pattern)
      found = re.search(find, line)
 
      if found:
        param = found.group(4)

        print '---------------------------------------------------------------------------'
        print ' [bug:SQLi:Wordpress] | file %s (param: %s) | line %d ' % ( path2file, param, nline )
        print '---------------------------------------------------------------------------'
        print ' file: %s in line %d' % ( path2file, nline)
        print ''
        print '  short desc: '
        print '    it looks like we got a Wordpress SQLi bug. (methods used)'
        print '    details below.'
        print ''
        print '  param: %s' % ( param )
        print '  code line:'
        print ''
        print line
        #print '---------------------------------------------------------------------------'
        print ''

## eof:check_sqli_methods
# 




# def:check_sqli_declar
def check_sqli_declar(path2file, target):

  fp = open(path2file, 'r')
  lines = fp.readlines()

  nline = 0
  global bugcount_sqli_declar

  for line in lines:
    nline = nline + 1

    pattern = "\$(.*?) = \$wpdb->get_results\('SELECT (.*?) WHERE(.*?)=(.*?)\$(.*?);"
    find = re.compile(pattern)
    found = re.search(find, line)

    if found:
      bugcount_sqli_declar = bugcount_sqli_declar + 1
      param = found.group(5)
      param = param.replace(')','')

      print '---------------------------------------------------------------------------'
      print ' [bug:SQLi:Wordpress] | file %s (param: %s) | line %d ' % ( path2file, param, nline )
      print '---------------------------------------------------------------------------'
      print ' file: %s in line %d' % ( path2file, nline)
      print ''
      print '  short desc: '
      print '    it looks like we got a Wordpress SQLi bug. (wrong declaration)'
      print '    details below.'
      print ''
      print '  param: %s' % ( param )
      print '  code line:'
      print ''
      print line
      #print '---------------------------------------------------------------------------'

      ## TODO:add verification of the parameter

      # sample verification
      print '  [+] proposed verification line(s):'
      for root, subdirs, files in os.walk(target):
        for file in os.listdir(root):
          fp = os.path.join(root, file)
          if os.path.isdir(fp):
            pass
          else:
            readme = open(fp, 'r')
            rlines = readme.readlines()

            methods = ['GET','POST','SERVER','COOKIE','SESSION','REQUEST','FILES']
            for method in methods:
              rlineNum = 0
              for rline in rlines:
                rlineNum = rlineNum + 1
                verifcomps = [
                  "\\$" + param + " =(.*?)\\$_" + method + "\[(.*?)\]",
                ]

                for verifcomp in verifcomps:
                  vercomp = re.compile( verifcomp )
                  verfound = re.search(vercomp, rline)

                  if verfound:
                    print '    found param verification: %s' % (param)
                    print '    in file: %s' % ( fp )
                    print '      used declaration: %s' % ( verfound.group(2) )
                    print '    possible line: (%d) \n%s\n' % ( rlineNum, rline )
                    print ''

        ## eof: checking declaration






## eof:check_sqli_declar
# 




# def:check_xss_methods
def check_xss_methods(path2file):

  fp = open(path2file, 'r')
  lines = fp.readlines()

  methods = [ 'GET','POST','REQUEST','SESSION','FILE','COOKIE' ]
  functions = [ 'echo ', 'return ', 'print ' ]

  nline = 0
  global bugcount_xss_methods

  for line in lines:
    nline = nline + 1

    for func in functions:
      for method in methods:
        pattern = func + "(.*?)\$_" + method + "\[(.*?)\]"
        find = re.compile(pattern)
        found = re.search(find, line)

        if found:
          bugcount_xss_methods = bugcount_xss_methods + 1
          param = found.group(2)

          print '---------------------------------------------------------------------------'
          print ' [bug:XSS:Wordpress] | file %s (param: %s) | line %d ' % ( path2file, param, nline )
          print '---------------------------------------------------------------------------'
          print ' file: %s in line %d' % ( path2file, nline)
          print ''
          print '  short desc: '
          print '    it looks like we got a basic Wordpress XSS bug. details below.'
          print ''
          print '  param: %s' % ( param )
          print '  code line:'
          print ''
          print line
          #print '---------------------------------------------------------------------------'
          print '\n\n'

          # TOTAL:
          print '[ Total found : %d ]' % ( bugcount_xss_methods )


#### 
# EOF v0.7
## 

# ---
# o/


